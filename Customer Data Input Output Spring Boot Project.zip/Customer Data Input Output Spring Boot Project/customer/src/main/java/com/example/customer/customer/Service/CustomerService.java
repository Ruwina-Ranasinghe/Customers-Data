package com.example.customer.customer.Service;

import com.example.customer.customer.Dao.CustomerCategoryDao;
import com.example.customer.customer.Dao.CustomerDao;
import com.example.customer.customer.Dto.CustomerDTO;
import com.example.customer.customer.Model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerService {
    @Autowired
    private CustomerDao customerDao;

    @Autowired
    private CustomerCategoryDao customerCategoryDao;

    public CustomerDTO saveAndUpdateCustomer(CustomerDTO customerDTO){
        Customer customer = null;

        if (customerDTO.getCustomerID()==null){
            customer = new Customer();
        }else {
            customer = customerDao.findByCustomerID(customerDTO.getCustomerID());
        }

        customer.setCustomerName(customerDTO.getCustomerName());
        customer.setMobileNumber(customerDTO.getMobileNumber());
        customer.setAddress(customerDTO.getAddress());
        customer.setGender(customerDTO.getGender());
        customer.setStetus(customerDTO.getStetus());

        customer.setCustomerCategory(customerCategoryDao.findByCustomerCategoryID(customerDTO.getCustomerCategoryID()));

        customer =customerDao.saveAndFlush(customer);

        return new CustomerDTO(customer);
    }

    public List<CustomerDTO>  getAllCustomers(){
        List<Customer> customers = customerDao.findAll();
        List<CustomerDTO>customerDTOS = new ArrayList<>();

        for (Customer customer:customers){
            CustomerDTO customerDTO = new CustomerDTO(customer);
            customerDTOS.add(customerDTO);
        }
       return customerDTOS;
    }

    public CustomerDTO  getCustomerByID(Integer customerID){
        Customer customer =customerDao.findByCustomerID(customerID);
        return new CustomerDTO(customer);
    }

    public List<CustomerDTO>getAllMaleCustomers(){
        List<Customer>customers=customerDao.findByGender("Male");
        List<CustomerDTO>customerDTOS = new ArrayList<>();

        for (Customer customer:customers){
         CustomerDTO customerDTO = new CustomerDTO(customer);

         customerDTOS.add(customerDTO);
        }
        return customerDTOS;
    }

}
