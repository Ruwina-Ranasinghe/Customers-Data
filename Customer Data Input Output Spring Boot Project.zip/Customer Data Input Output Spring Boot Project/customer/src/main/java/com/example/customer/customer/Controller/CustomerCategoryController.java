package com.example.customer.customer.Controller;

import com.example.customer.customer.Dto.CustomerCategoryDTO;
import com.example.customer.customer.Service.CustomerCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerCategoryController {
    @Autowired
    private CustomerCategoryService customerCategoryService;

    @RequestMapping(value = "/saveAndUpdateCustomerCategory",method = RequestMethod.POST)
    public CustomerCategoryDTO saveAndUpdateCustomerCategory(@RequestBody CustomerCategoryDTO customerCategoryDTO){
        CustomerCategoryDTO customerCategoryDTO1 = this.customerCategoryService.saveAndUpdateCustomerCategory(customerCategoryDTO);
        return customerCategoryDTO1;

    }

    @RequestMapping(value = "/getAllCustomerCategories",method = RequestMethod.GET)
    public List<CustomerCategoryDTO>getAllCustomerCategories(){
        List<CustomerCategoryDTO> customerCategoryDTOS= this.customerCategoryService.getAllCustomerCategories();
        return customerCategoryDTOS;
    }

    @RequestMapping(value = "/getCustomerCategoryByID/{customerCategoryID}",method = RequestMethod.GET)
    public CustomerCategoryDTO getCustomerCategoryByID(@PathVariable Integer customerCategoryID){
        CustomerCategoryDTO customerCategoryDTO = this.customerCategoryService.getCustomerCategoryByID(customerCategoryID);
        return customerCategoryDTO;
    }
}
