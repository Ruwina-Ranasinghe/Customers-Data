package com.example.customer.customer.Service;

import com.example.customer.customer.Dao.CustomerCategoryDao;
import com.example.customer.customer.Dto.CustomerCategoryDTO;
import com.example.customer.customer.Model.CustomerCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerCategoryService {
    @Autowired
    private CustomerCategoryDao customerCategoryDao;

    public CustomerCategoryDTO  saveAndUpdateCustomerCategory(CustomerCategoryDTO customerCategoryDTO){
        CustomerCategory customerCategory = null;

        if(customerCategoryDTO.getCustomerCategoryID()==null){
            customerCategory = new CustomerCategory();
        }else {
            customerCategory = customerCategoryDao.findByCustomerCategoryID(customerCategoryDTO.getCustomerCategoryID());
        }

        customerCategory.setCustomerCategoryName(customerCategoryDTO.getCustomerCategoryName());
        customerCategory.setStetus(customerCategoryDTO.getStetus());

        customerCategory =customerCategoryDao.saveAndFlush(customerCategory);

        return new CustomerCategoryDTO(customerCategory);
    }



    public List<CustomerCategoryDTO>getAllCustomerCategories(){
        List<CustomerCategory>customerCategory=customerCategoryDao.findAll();
        List<CustomerCategoryDTO>customerCategoryDTOS = new ArrayList<>();

        for (CustomerCategory customerCategory1:customerCategory){
            CustomerCategoryDTO customerCategoryDTO = new CustomerCategoryDTO(customerCategory1);
            customerCategoryDTOS.add(customerCategoryDTO);
        }

        return customerCategoryDTOS;
    }

    public CustomerCategoryDTO getCustomerCategoryByID(Integer customerCategoryDTO){
        CustomerCategory customerCategory = customerCategoryDao.findByCustomerCategoryID(customerCategoryDTO);
        return new CustomerCategoryDTO(customerCategory);
    }
}
