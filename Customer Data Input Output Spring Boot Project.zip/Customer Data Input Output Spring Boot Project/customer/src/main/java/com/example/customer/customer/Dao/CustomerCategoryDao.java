package com.example.customer.customer.Dao;

import com.example.customer.customer.Model.CustomerCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerCategoryDao extends JpaRepository<CustomerCategory,Integer> {
    CustomerCategory findByCustomerCategoryID (Integer customerCategoryID);
}
