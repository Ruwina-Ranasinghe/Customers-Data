package com.example.customer.customer.Dto;

import com.example.customer.customer.Model.Customer;

public class CustomerDTO {
    private Integer customerID;

    private String customerName;

    private String mobileNumber;

    private String address;

    private String gender;

    private String stetus;

    private Integer customerCategoryID;

    public CustomerDTO() {
    }

    public CustomerDTO(Customer customer) {
        this.customerID = customer.getCustomerID();
        this.customerName = customer.getCustomerName();
        this.mobileNumber = customer.getMobileNumber();
        this.address = customer.getAddress();
        this.gender = customer.getGender();
        this.stetus = customer.getStetus();

        if (customer.getCustomerCategory()!= null){
            this.customerCategoryID = customer.getCustomerCategory().getCustomerCategoryID();
        }
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String  mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStetus() {
        return stetus;
    }

    public void setStetus(String stetus) {
        this.stetus = stetus;
    }

    public Integer getCustomerCategoryID() {
        return customerCategoryID;
    }

    public void setCustomerCategoryID(Integer customerCategoryID) {
        this.customerCategoryID = customerCategoryID;
    }
}
