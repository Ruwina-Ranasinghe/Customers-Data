package com.example.customer.customer.Controller;

import com.example.customer.customer.Dto.CustomerDTO;
import com.example.customer.customer.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {
    @Autowired
   private CustomerService customerService;

    @RequestMapping(value = "/saveAndUpdateCustomer",method = RequestMethod.POST)
    public CustomerDTO saveAndUpdateCustomer(@RequestBody CustomerDTO customerDTO){
        CustomerDTO customerDTO1 =this.customerService.saveAndUpdateCustomer(customerDTO);

        return customerDTO1;
    }
    @RequestMapping(value = "/getAllCustomers",method = RequestMethod.GET)
    public List<CustomerDTO>getAllCustomers(){
        List<CustomerDTO> customerDTOS= this.customerService.getAllCustomers();
        return customerDTOS;
    }

    @RequestMapping(value = "/getCustomerByID/{customerID}",method = RequestMethod.GET)
    public CustomerDTO getCustomerByID(@PathVariable Integer customerID){
        CustomerDTO customerDTO = this.customerService.getCustomerByID(customerID);
        return customerDTO;
    }

    @RequestMapping(value = "/getAllMaleCustomers",method = RequestMethod.GET)
    public List<CustomerDTO> getAllMaleCustomers(){
       List< CustomerDTO> customerDTO=this.customerService.getAllMaleCustomers();
        return customerDTO;
    }
}
