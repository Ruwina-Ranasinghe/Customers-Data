package com.example.customer.customer.Dto;

import com.example.customer.customer.Model.CustomerCategory;

public class CustomerCategoryDTO {
    private Integer customerCategoryID;

    private String customerCategoryName;

    private String stetus;

    public CustomerCategoryDTO() {
    }

    public CustomerCategoryDTO(CustomerCategory customerCategory) {
        this.customerCategoryID = customerCategory.getCustomerCategoryID();
        this.customerCategoryName = customerCategory.getCustomerCategoryName();
        this.stetus = customerCategory.getStetus();
    }

    public Integer getCustomerCategoryID() {
        return customerCategoryID;
    }

    public void setCustomerCategoryID(Integer customerCategoryID) {
        this.customerCategoryID = customerCategoryID;
    }

    public String getCustomerCategoryName() {
        return customerCategoryName;
    }

    public void setCustomerCategoryName(String customerCategoryName) {
        this.customerCategoryName = customerCategoryName;
    }

    public String getStetus() {
        return stetus;
    }

    public void setStetus(String stetus) {
        this.stetus = stetus;
    }
}
