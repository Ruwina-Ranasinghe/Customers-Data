package com.example.customer.customer.Dao;

import com.example.customer.customer.Model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerDao extends JpaRepository<Customer,Integer> {
    Customer findByCustomerID(Integer customerID);
   List<Customer> findByGender(String gender);
}
