package com.example.customer.customer.Service;

import com.example.customer.customer.Dto.CustomerCategoryDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerCategoryServiceTest {
    @Autowired
    private CustomerCategoryService customerCategoryService;

    @Test
    void saveAndUpdate(){
        CustomerCategoryDTO customerCategoryDTO = new CustomerCategoryDTO();

        customerCategoryDTO.setCustomerCategoryID(null);
        customerCategoryDTO.setCustomerCategoryName("");
        customerCategoryDTO.setStetus("");

        customerCategoryService.saveAndUpdateCustomerCategory(customerCategoryDTO);
    }

    @Test
    void getAllCustomerCategories(){
        this.customerCategoryService.getAllCustomerCategories();
    }

    @Test
    void etCustomerCategoryByID(){
        this.customerCategoryService.getCustomerCategoryByID(null);
    }
}