package com.example.customer.customer.Service;

import com.example.customer.customer.Dto.CustomerDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerServiceTest {

    @Autowired
    private CustomerService customerService;
    @Test
    void saveAndUpdateCustomer() {
        CustomerDTO customerDTO =new CustomerDTO();
        customerDTO.setCustomerID(null);
        customerDTO.setCustomerCategoryID(null);
        customerDTO.setCustomerName("");
        customerDTO.setMobileNumber("");
        customerDTO.setAddress("");
        customerDTO.setGender("");
        customerDTO.setStetus("");

        customerService.saveAndUpdateCustomer(customerDTO);

    }

    @Test
    void getAllCustomers() {
       this.customerService.getAllCustomers();
    }

    @Test
    void getCustomerByID() {
        this.customerService.getCustomerByID(null);
    }

    @Test
    void getAllMaleCustomers() {
        this.customerService.getAllMaleCustomers();
    }
}